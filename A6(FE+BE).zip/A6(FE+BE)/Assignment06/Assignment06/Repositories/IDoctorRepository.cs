﻿using Assignment06.Models;
using System.Collections.Generic;

namespace Assignment06.Repositories
{
    public interface IDoctorRepository
    {
        IEnumerable<Doctor> GetAll();
        Doctor GetById(int id);
        void Add(Doctor doctor);
        void Update(Doctor doctor);
        void Delete(int id);
    }
}
