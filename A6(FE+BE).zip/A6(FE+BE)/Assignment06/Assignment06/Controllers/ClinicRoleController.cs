﻿using Microsoft.AspNetCore.Mvc;
using Assignment06.Models;
using Assignment06.Services;

namespace Assignment06.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ClinicRolesController : ControllerBase
    {
        private readonly IClinicRoleService _service;

        public ClinicRolesController(IClinicRoleService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_service.GetAll());
        }

        [HttpPost]
        public IActionResult Add(ClinicRole role)
        {
            _service.Add(role);
            return Ok("Role added successfully");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _service.Delete(id);
            return Ok("Role deleted successfully");
        }
    }
}
