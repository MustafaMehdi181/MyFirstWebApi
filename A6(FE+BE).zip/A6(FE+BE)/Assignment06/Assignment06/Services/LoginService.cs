﻿using Assignment06.Models;
using Assignment06.Repositories;

namespace Assignment06.Services
{
    public interface ILoginService
    {
        void Register(LoginModel login);
        bool ValidateUser(string email, string password);
    }
}


namespace Assignment06.Services
{
    public class LoginService : ILoginService
    {
        private readonly ILoginRepository _repository;

        public LoginService(ILoginRepository repository)
        {
            _repository = repository;
        }

        public void Register(LoginModel login)
        {
            _repository.Register(login);
        }

        public bool ValidateUser(string email, string password)
        {
            return _repository.ValidateUser(email, password);
        }
    }
}
