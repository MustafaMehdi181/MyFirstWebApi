﻿using Assignment06.Models;
using System.Collections.Generic;

namespace Assignment06.Services
{
    public interface IClinicRoleService
    {
        IEnumerable<ClinicRole> GetAll();
        void Add(ClinicRole role);
        void Delete(int id);
    }
}
