﻿using Assignment06.Models;
using System.Data.SqlClient;
using Assignment06.Models;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace Assignment06.Repositories
{
    public interface ILoginRepository
    {
        void Register(LoginModel login);
        bool ValidateUser(string email, string password);
    }
}




namespace Assignment06.Repositories
{
    public class LoginRepository : ILoginRepository
    {
        private readonly string _connectionString;

        public LoginRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public void Register(LoginModel login)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                string query = "INSERT INTO Login (email, passwords) VALUES (@Email, @Passwords)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Email", login.Email);
                cmd.Parameters.AddWithValue("@Passwords", login.Passwords);
                cmd.ExecuteNonQuery();
            }
        }

        public bool ValidateUser(string email, string password)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM Login WHERE email = @Email AND passwords = @Passwords";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Passwords", password);

                int count = (int)cmd.ExecuteScalar();
                return count > 0;
            }
        }
    }
}
