﻿using Assignment06.Models;
using System.Collections.Generic;

namespace Assignment06.Services
{
    public interface IVisitService
    {
        IEnumerable<Visit> GetAll();
        void Add(Visit visit);
        void Update(Visit visit);
        void Delete(int id);
    }
}
