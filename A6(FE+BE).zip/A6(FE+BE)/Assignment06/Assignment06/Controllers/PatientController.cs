﻿using Assignment06.Models;
using Microsoft.AspNetCore.Mvc;
using Assignment06.Models;
using Assignment06.Services;

namespace Assignment06.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PatientsController : ControllerBase
    {
        private readonly IPatientService _service;

        public PatientsController(IPatientService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_service.GetAll());
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var patient = _service.GetById(id);
            if (patient == null) return NotFound();
            return Ok(patient);
        }

        [HttpPost]
        public IActionResult Add(Patient patient)
        {
            _service.Add(patient);
            return Ok("Patient added successfully");
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, Patient patient)
        {
            if (id != patient.PatientId) return BadRequest();
            _service.Update(patient);
            return Ok("Patient updated successfully");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _service.Delete(id);
            return Ok("Patient deleted successfully");
        }
    }
}
