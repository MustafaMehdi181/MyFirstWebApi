﻿using Assignment06.Models;
using System.Collections.Generic;

namespace Assignment06.Services
{
    public interface IPatientService
    {
        IEnumerable<Patient> GetAll();
        Patient GetById(int id);
        void Add(Patient patient);
        void Update(Patient patient);
        void Delete(int id);
    }
}
