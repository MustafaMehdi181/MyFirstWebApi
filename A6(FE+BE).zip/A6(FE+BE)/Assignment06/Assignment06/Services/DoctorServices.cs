﻿using Assignment06.Models;
using Assignment06.Repositories;

namespace Assignment06.Services
{
    public class DoctorService : IDoctorService
    {
        private readonly IDoctorRepository _repository;

        public DoctorService(IDoctorRepository repository)
        {
            _repository = repository;
        }

        public IEnumerable<Doctor> GetAll() => _repository.GetAll();

        public Doctor GetById(int id) => _repository.GetById(id);

        public void Add(Doctor doctor) => _repository.Add(doctor);

        public void Update(Doctor doctor) => _repository.Update(doctor);

        public void Delete(int id) => _repository.Delete(id);
    }
}
