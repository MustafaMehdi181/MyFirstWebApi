﻿using Assignment06.Models;
using Assignment06.Repositories;

namespace Assignment06.Services
{
    public class VisitTypeService : IVisitTypeService
    {
        private readonly IVisitTypeRepository _repository;

        public VisitTypeService(IVisitTypeRepository repository)
        {
            _repository = repository;
        }

        public IEnumerable<VisitType> GetAll() => _repository.GetAll();

        public void Add(VisitType visitType) => _repository.Add(visitType);
    }
}
