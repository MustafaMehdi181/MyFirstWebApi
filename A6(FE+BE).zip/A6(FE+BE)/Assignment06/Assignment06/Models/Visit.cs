﻿namespace Assignment06.Models
{
    public class Visit
    {
        public int VisitId { get; set; }
        public int PatientId { get; set; }
        public int DoctorId { get; set; }
        public int VisitTypeId { get; set; }
        public int Duration { get; set; }
        public DateTime VisitDate { get; set; }
        public string? DoctorNotes { get; set; }
    }
}
