﻿using Microsoft.AspNetCore.Mvc;
using Assignment06.Models;
using Assignment06.Services;

namespace Assignment06.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DoctorsController : ControllerBase
    {
        private readonly IDoctorService _service;

        public DoctorsController(IDoctorService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_service.GetAll());
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var doctor = _service.GetById(id);
            if (doctor == null) return NotFound();
            return Ok(doctor);
        }

        [HttpPost]
        public IActionResult Add(Doctor doctor)
        {
            _service.Add(doctor);
            return Ok("Doctor added successfully");
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, Doctor doctor)
        {
            if (id != doctor.DoctorId) return BadRequest();
            _service.Update(doctor);
            return Ok("Doctor updated successfully");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _service.Delete(id);
            return Ok("Doctor deleted successfully");
        }
    }
}
