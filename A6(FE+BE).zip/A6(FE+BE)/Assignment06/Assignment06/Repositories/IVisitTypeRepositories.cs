﻿using Assignment06.Models;
using System.Collections.Generic;

namespace Assignment06.Repositories
{
    public interface IVisitTypeRepository
    {
        IEnumerable<VisitType> GetAll();
        void Add(VisitType visitType);
    }
}
