﻿using Microsoft.AspNetCore.Mvc;
using Assignment06.Models;
using Assignment06.Services;

namespace Assignment06.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly ILoginService _service;

        public UserController(ILoginService service)
        {
            _service = service;
        }

        [HttpPost("register")]
        public IActionResult Register(LoginModel login)
        {
            _service.Register(login);
            return Ok("User registered successfully.");
        }

        [HttpPost("login")]
        public IActionResult Login(LoginModel login)
        {
            if (_service.ValidateUser(login.Email, login.Passwords))
                return Ok($"Welcome to the website, {login.Email}!");
            else
                return Unauthorized("Invalid email or password.");
        }
    }
}
