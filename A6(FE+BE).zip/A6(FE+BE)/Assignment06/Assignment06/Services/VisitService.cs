﻿using Assignment06.Models;
using Assignment06.Repositories;

namespace Assignment06.Services
{
    public class VisitService : IVisitService
    {
        private readonly IVisitRepository _repository;

        public VisitService(IVisitRepository repository)
        {
            _repository = repository;
        }

        public IEnumerable<Visit> GetAll() => _repository.GetAll();

        public void Add(Visit visit) => _repository.Add(visit);

        public void Update(Visit visit) => _repository.Update(visit);

        public void Delete(int id) => _repository.Delete(id);
    }
}
