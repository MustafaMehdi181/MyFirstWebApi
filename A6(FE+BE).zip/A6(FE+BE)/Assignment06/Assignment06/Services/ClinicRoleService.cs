﻿using Assignment06.Models;
using Assignment06.Repositories;

namespace Assignment06.Services
{
    public class ClinicRoleService : IClinicRoleService
    {
        private readonly IClinicRoleRepository _repository;

        public ClinicRoleService(IClinicRoleRepository repository)
        {
            _repository = repository;
        }

        public IEnumerable<ClinicRole> GetAll() => _repository.GetAll();

        public void Add(ClinicRole role) => _repository.Add(role);

        public void Delete(int id) => _repository.Delete(id);
    }
}
