﻿using System.Data.SqlClient;
using Assignment06.Models;

namespace Assignment06.Repositories
{
    public class VisitTypeRepository : IVisitTypeRepository
    {
        private readonly string _connectionString;

        public VisitTypeRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public IEnumerable<VisitType> GetAll()
        {
            var visitTypes = new List<VisitType>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM VisitTypes", conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    visitTypes.Add(new VisitType
                    {
                        VisitTypeId = (int)reader["VisitTypeId"],
                        VisitTypeName = reader["VisitTypeName"].ToString(),
                        Fee = (decimal)reader["Fee"]
                    });
                }
            }
            return visitTypes;
        }

        public void Add(VisitType visitType)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO VisitTypes (VisitTypeName, Fee) VALUES (@Name, @Fee)", conn);
                cmd.Parameters.AddWithValue("@Name", visitType.VisitTypeName);
                cmd.Parameters.AddWithValue("@Fee", visitType.Fee);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
