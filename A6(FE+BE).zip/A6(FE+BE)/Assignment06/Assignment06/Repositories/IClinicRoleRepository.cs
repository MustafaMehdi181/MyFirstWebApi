﻿using Assignment06.Models;
using System.Collections.Generic;

namespace Assignment06.Repositories
{
    public interface IClinicRoleRepository
    {
        IEnumerable<ClinicRole> GetAll();
        void Add(ClinicRole role);
        void Delete(int id);
    }
}
