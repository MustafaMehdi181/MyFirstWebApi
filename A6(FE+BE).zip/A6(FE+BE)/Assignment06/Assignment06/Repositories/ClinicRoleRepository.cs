﻿using System.Data.SqlClient;
using Assignment06.Models;

namespace Assignment06.Repositories
{
    public class ClinicRoleRepository : IClinicRoleRepository
    {
        private readonly string _connectionString;

        public ClinicRoleRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public IEnumerable<ClinicRole> GetAll()
        {
            var roles = new List<ClinicRole>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM ClinicRoles", conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    roles.Add(new ClinicRole
                    {
                        RoleId = (int)reader["RoleId"],
                        RoleName = reader["RoleName"].ToString()
                    });
                }
            }
            return roles;
        }

        public void Add(ClinicRole role)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO ClinicRoles (RoleName) VALUES (@RoleName)", conn);
                cmd.Parameters.AddWithValue("@RoleName", role.RoleName);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void Delete(int id)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM ClinicRoles WHERE RoleId = @Id", conn);
                cmd.Parameters.AddWithValue("@Id", id);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
