﻿using Microsoft.AspNetCore.Mvc;
using Assignment06.Models;
using Assignment06.Services;

namespace Assignment06.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VisitsController : ControllerBase
    {
        private readonly IVisitService _service;

        public VisitsController(IVisitService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_service.GetAll());
        }

        [HttpPost]
        public IActionResult Add(Visit visit)
        {
            _service.Add(visit);
            return Ok("Visit added successfully");
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, Visit visit)
        {
            if (id != visit.VisitId) return BadRequest();
            _service.Update(visit);
            return Ok("Visit updated successfully");
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _service.Delete(id);
            return Ok("Visit deleted successfully");
        }
    }
}
