﻿using System.Data;
using System.Data.SqlClient;
using Assignment06.Models;

namespace Assignment06.Repositories
{
    public class PatientRepository : IPatientRepository
    {
        private readonly string _connectionString;

        public PatientRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public IEnumerable<Patient> GetAll()
        {
            var patients = new List<Patient>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Patients", conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    patients.Add(new Patient
                    {
                        PatientId = (int)reader["PatientId"],
                        PatientName = reader["PatientName"].ToString(),
                        PatientPhone = reader["PatientPhone"].ToString()
                    });
                }
            }
            return patients;
        }

        public Patient GetById(int id)
        {
            Patient patient = null;

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Patients WHERE PatientId = @Id", conn);
                cmd.Parameters.AddWithValue("@Id", id);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    patient = new Patient
                    {
                        PatientId = (int)reader["PatientId"],
                        PatientName = reader["PatientName"].ToString(),
                        PatientPhone = reader["PatientPhone"].ToString()
                    };
                }
            }
            return patient;
        }

        public void Add(Patient patient)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO Patients (PatientName, PatientPhone) VALUES (@Name, @Phone)", conn);
                cmd.Parameters.AddWithValue("@Name", patient.PatientName);
                cmd.Parameters.AddWithValue("@Phone", patient.PatientPhone);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void Update(Patient patient)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand(
                    "UPDATE Patients SET PatientName = @Name, PatientPhone = @Phone WHERE PatientId = @Id", conn);
                cmd.Parameters.AddWithValue("@Id", patient.PatientId);
                cmd.Parameters.AddWithValue("@Name", patient.PatientName);
                cmd.Parameters.AddWithValue("@Phone", patient.PatientPhone);
                

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void Delete(int id)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Patients WHERE PatientId = @Id", conn);
                cmd.Parameters.AddWithValue("@Id", id);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
