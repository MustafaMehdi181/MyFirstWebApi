﻿using Microsoft.AspNetCore.Mvc;
using Assignment06.Models;
using Assignment06.Services;

namespace Assignment06.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VisitTypesController : ControllerBase
    {
        private readonly IVisitTypeService _service;

        public VisitTypesController(IVisitTypeService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_service.GetAll());
        }

        [HttpPost]
        public IActionResult Add(VisitType visitType)
        {
            _service.Add(visitType);
            return Ok("Visit type added successfully");
        }
    }
}
