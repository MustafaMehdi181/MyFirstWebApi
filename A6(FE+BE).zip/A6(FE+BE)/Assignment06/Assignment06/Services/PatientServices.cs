﻿using Assignment06.Models;
using Assignment06.Repositories;

namespace Assignment06.Services
{
    public class PatientService : IPatientService
    {
        private readonly IPatientRepository _repository;

        public PatientService(IPatientRepository repository)
        {
            _repository = repository;
        }

        public IEnumerable<Patient> GetAll() => _repository.GetAll();

        public Patient GetById(int id) => _repository.GetById(id);

        public void Add(Patient patient) => _repository.Add(patient);

        public void Update(Patient patient) => _repository.Update(patient);

        public void Delete(int id) => _repository.Delete(id);
    }
}
